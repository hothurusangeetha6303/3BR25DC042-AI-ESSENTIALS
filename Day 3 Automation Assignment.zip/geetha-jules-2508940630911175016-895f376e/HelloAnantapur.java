public class HelloAnantapur {
    public static void main(String[] args) {
        System.out.println("Hello Anantapur");
    }
}
